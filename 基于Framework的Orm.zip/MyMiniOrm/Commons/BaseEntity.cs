﻿namespace MyMiniOrm.Commons
{
    public class BaseEntity : IEntity
    {
        public virtual int Id { get; set; }
    }
}
