﻿namespace MyMiniOrm.Commons
{
    public interface ISoftDelete
    {
        bool IsDel { get; set; }
    }
}
