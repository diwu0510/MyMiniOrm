﻿namespace MyMiniOrm.Commons
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}
