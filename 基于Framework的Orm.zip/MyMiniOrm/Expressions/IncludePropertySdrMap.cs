﻿namespace MyMiniOrm.Expressions
{
    public class IncludePropertySdrMap
    {
        public string PropertyName { get; set; }

        public int Index { get; set; }
    }
}
