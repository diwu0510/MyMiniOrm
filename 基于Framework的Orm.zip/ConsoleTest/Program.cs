﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyMiniOrm.Queryable;

namespace ConsoleTest
{
    class Program
    {
        static void Main(string[] args)
        {
            //var query = new MyQueryable<Student>();
            //var list = query.Include(q => q.Clazz).Where(q => q.Id > 1).OrderBy(q => q.Name).ToList();

            //foreach (var student in list)
            //{
            //    Console.WriteLine($"{student.Name} - {student.Clazz.Name}");
            //}

            //Console.WriteLine("");

            var query2 = new MyQueryable<Student>();
            var list2 = query2
                .Include(q => q.Clazz)
                .Where(q => q.Clazz.Id > 1)
                .OrderBy(q => q.Name)
                .ToPageList(2, 2, out var recordCount);

            foreach (var student in list2)
            {
                Console.WriteLine($"{student.Name} - {student.Clazz.Name}");
            }

            Console.WriteLine(recordCount);

            Console.Read();
        }
    }
}
